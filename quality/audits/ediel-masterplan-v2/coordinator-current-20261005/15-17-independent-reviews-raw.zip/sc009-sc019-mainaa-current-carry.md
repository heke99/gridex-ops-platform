# SC009 / SC019 — fresh mainaa carry

**APPROVE minimum source/SQL/union carry** for #544 `4e6b196e9957606d6e05b9259e1a8a2303930be7` against freshly read actual main `aa271e14b8a39145dca04aa1433dd54be88f44bd` / tree `b519b327`. Expected conflict-free union: **`bea17d9ab23d63a407a120569cd7821d2acaccda`**.

Reuse the immutable prior independent receipt [sc009-sc019-final-carry.json](sc009-sc019-final-carry.json), SHA256 `8678f7c1d771a6db35d45b8264b61006c6aaa25511c51f972751449cd13b2d15`. 29 selected source files and 23 complete SQL definitions retain their reviewed pins. Current app/lib, schema, migrations, raw generated outputs, workflows, eight capture inputs and registered native configuration are byte-identical to adopted main3dff/published owner. No new reached production delta exists.

Foreign verification additions are preserved exactly: SC004/SC006 finite test consumers, SC057/SC059 asserting files, SC034 complete LIN-refusal native variants, and unregistered Z06F/G proposal files. No original selected asserting file or tag union is lost. All 352 IDs/order/main metadata and all **350 foreign rows with ordered evidence** match current main; 7,791 foreign main paths are exact. Only this pair's rows differ: main222 → union224.

Retained original whole literal approval, existing 32/32 raw results and finite DB06/native evidence boundaries. No positive DGI invoice, rewritten DDQ source or fresh whole-native proof is inferred. No test, SQL, native, tagger, capture, full run or broad review was repeated; no owner edits/push/merge.

Fresh JSON SHA256: `98c5bf162bed5a2d404f090537b27706d72fe05f49e681f741111649377de4de`. Root watches exact owner-head gates (clean was pending in its 15:03 snapshot), refreshes main and handles guarded publication/merge. This carry does not assert all-nine success or combined-tree runtime qualification.

