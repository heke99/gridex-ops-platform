# SC013 / SC020 — fresh mainaa carry

**APPROVE minimum source/SQL/union carry** for #548 `99af21336aac95c7df6ab9e788ae42d0c6e92dea` against freshly read actual main `aa271e14b8a39145dca04aa1433dd54be88f44bd` / tree `b519b327`. Expected conflict-free union: **`80d5b295ceae1c65b57b924a42e259897b5412cd`**.

Reuse the immutable prior independent receipt [sc013-sc020-99af-final-carry.json](sc013-sc020-99af-final-carry.json), SHA256 `108142eecd8381d1ab3d1e5c44581cf334edbd9fddbff87b1663d9c4438f55ca`. 22 selected source files, 6 complete selected SQL definitions plus 119 complete transitive definitions, and 13 retained installed migrations retain their reviewed pins. Current app/lib, schema, migrations, raw generated outputs, workflows, eight capture inputs and registered native configuration are byte-identical to adopted main3dff/published owner. No new reached production delta exists.

Foreign verification additions are preserved exactly: SC004/SC006 finite test consumers, SC057/SC059 asserting files, SC034 complete LIN-refusal native variants, and unregistered Z06F/G proposal files. No original selected asserting file or tag union is lost. All 352 IDs/order/main metadata and all **350 foreign rows with ordered evidence** match current main; 7,788 foreign main paths are exact. Only this pair's rows differ: main222 → union224.

Retained original whole literal approval, existing 53/53 raw results and declared SDK/finite READ/STORE/source-ACK boundaries. Historical nested ANJ RED and old clean failure remain historical; no native/custody/latest-whole-RPC proof is inferred. No test, SQL, native, tagger, capture, full run or broad review was repeated; no owner edits/push/merge.

Fresh JSON SHA256: `dafe875f94077238959bfd215db9615dcd0b64f3991137912a8023a9e9991b78`. Root watches exact owner-head gates (clean was pending in its 15:03 snapshot), refreshes main and handles guarded publication/merge. This carry does not assert all-nine success or combined-tree runtime qualification.

