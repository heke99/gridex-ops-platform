# SC009 / SC019 — minimum fresh maincf carry

**APPROVE** #544 head `4e6b196e` against actual main `cf275d78d252bdaa8e49fb4e5f65afaa61bf0128` / tree `80d5b295`. API/Git agree on genuine main parents aa+99af. Expected clean union: **`5a2e90a343dbd417014d4710104eafa19319d86b`**.

Prior receipt `98c5bf16` is retained. Main's #548 delta changes only its own consumers/tags/mock ports, records and two rows. The 29 reviewed source pins, 23 complete SQL definitions, three original owned asserting suites, eight capture inputs and raw generation remain unchanged.

All 352 IDs/order/main metadata and 350 foreign rows with ordered evidence are exact. Only SC009/SC019 differ; main224 → candidate226. Original whole-literal and finite/native boundaries remain, including held DGI, no DDQ rewrite and no invented positive invoice.

No repeated tests/native/capture/whole review or owner mutations. Root owns latest nine-gate/CodeRabbit qualification, public receipt and guarded merge.

