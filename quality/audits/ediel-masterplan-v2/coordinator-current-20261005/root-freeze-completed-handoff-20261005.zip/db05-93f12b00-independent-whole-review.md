# DB-05 / AT-DB-05 independent complete-card review

**Verdict: HOLD complete-card approval at `93f12b0079779eeadba4a5034bc1e8acc421ce1a`, tree `62b84aa392ab758118bc3b482ad06605d85445c0`.** The new hard-delete repair and three DB-05 native component cases are genuinely green. One concrete post-closure retention scenario remains unsupported by the current production permission and selector path. No reviewer SQL, native, unit, full suite, source write, manifest change, coverage promotion or GitHub publication was performed.

Frozen scope is A_Regelkort DB-05 (line 1717) and D_Acceptanskontrakt AT-DB-05 (line 2332): distinguish operational wind-down, access revocation, personal-data purge and required journal/settlement retention; use a decided class workflow with authorized basis; neither blanket CASCADE history loss nor indefinite blanket retention is allowed. SC070 is corroborating context, not an additional owned approval. This is code/behavior review, never lawful-period, market, production or physical-Storage approval.

## Verified current native custody

Authenticated public GitHub repository and head repository are `heke99/gridex-ops-platform`, ID 1190539955. Run `37331134378`, attempt 1, exact head 93f12b00, push on `claude/magical-cerf-55zxau`, workflow `.github/workflows/ediel-db04-native.yml`, and job `111834218090` all match. Job completed SUCCESS at 2026-10-05T15:21:43Z. Its canonical clean replay step completed successfully before the selected real PostgreSQL/GoTrue native execution. Source checkout uses github.sha; Node22 and Supabase2.101.0 are pinned. Selected config contains exactly four one-case files: three DB-05 files and the separate DB-04 query-plan file. The authenticated log records 4/4 PASS. No DB-04 query-plan re-review was conducted or credited to DB-05.

Artifact `11354068848`, `db04-query-plans`, was created at 15:21:39Z inside the job window and binds repository/run/head. Its 5042-byte ZIP SHA256 equals the GitHub digest:
`277bec245af994dc10ae4f6114ecb2e56b4580a8e70f92848311d6610c622315`.
CRC verification passes and there is exactly one member, `plans.json`, SHA256
`d7f0a9a5f48239c0c1034584703379a432a6f74b79e9a740f9ded6e33ef8b931`.
It contains retained DB-05 JSON facts for guarded deletion and offboarding. The personal-class case is proven by its exact source-selected file outcome in the authenticated log; it does not emit a JSON fact. There is no JUnit member, no exact-input receipt emitted by this workflow, and no fabricated JUnit/case receipt is inferred. The exact authenticated Git head/tree binds the source, and each selected file has one unskipped it declaration.

Local genuine ZIP:
`/workspace/attachments/257509e6-8d74-4202-8f80-b03ce901330a/db05-native-93f12b00.zip`.
Byte-exact authenticated job log:
`/workspace/agent-review-checkpoints/db05-93f12b00-authenticated-native-job.log`,
SHA256 `ddde3d4a92df5b5c8afc4b0a7073dd5e53a2a0a84317966e0069561f77991d5a`.
Selected source/body/FK hashes are in `db05-93f12b00-source-qualification.json`,
SHA256 `fbeba8b89e6e2b82659da42c98c3e7f3f97e13be71abc7c992030ad49e97a086`
(66 selected reviewed inputs; not a claimed exhaustive TS dependency closure).

## Complete effect mapping

| Frozen effect | Actual producer/caller and proof | Limit/verdict |
| --- | --- | --- |
| Operational wind-down and access revoke are distinct from purge | Current canonical_transition_tenant_lifecycle chain; native offboarding refuses unauthorized actor and unsettled billing with exact unchanged snapshot, then closes and revokes API client/webhook/portal identity/sessions while keeping customer, email, event and audit rows | Current native PASS, real installed SQL; actor, membership, customer and billing givens are synthetic |
| Raw company/customer deletion must preserve retained history | Invoker DELETE/status/TRUNCATE guards; genuine service_role company/customer/direct-disposable-status and audit TRUNCATE refusals; all four enabled guard names and 448 TRUNCATE guards; sanctioned SECURITY DEFINER test-customer deletion succeeds | Current native PASS. Owner maintenance remains an explicitly trusted boundary |
| Canonical lifecycle must not mark retained real tenant disposable | 93f status trigger repeats actual retained-history check even under the definer; native actual pending_deletion succeeds, disposable transition raises 23001, raw deletion raises 23001; exact retained customer/event/seeded audit remain | Current native PASS for actual seeded real-customer/history tuple; 10a historical pass is not credited to changed93f |
| Per-class legal basis/current source/reviewer/grants govern purge | Actual artifact/customer/blob/record/process owner SQL and runtime session-to-RPC/Storage paths; existing bounded9+10 scripts assert issuer absence, exact HMAC/source/document/class/deadline, separate current reviewer/DENY/revocation, foreign scope, active supply, rollback, private ACLs and immutable hashes/tombstones | Actual finite SQL mechanisms, not genuine legal authority/full native schema/physical Storage. The published immutable blob receipt contains9 PASS groups. The author checkpoint documents9+10 PASS, but raw10-group receipt and current exact-input qualification were not independently supplied during this review |
| Approved personal-field purge removes data and revokes access without whole history deletion | Actual installed native customer-class submit/review/pseudonymise under real GoTrue JWT/RPC; no issuer held, source edit held, foreign tenant refused, archived company ordinary write denied, exact own field purge, portal revoke, unrelated customer unchanged, one audit/hash tombstone and exact replay | Current native PASS with synthetic legal competence, policy/deadline and operative archived-customer/company givens |
| After actual terminal tenant close, later lawful class purge remains available through its separate authority | Current retention permission resolvers and company-selection caller | **HOLD: current source excludes closed; positive native purge only uses archived, not actual closed tenant** |

## Decisive source-level gap: terminal closure prevents later class workflow

The current actual canonical command writes `companies.status='closed'`; its underlying transition map makes closed terminal. Current captured `gridex_ediel_retention.permission_v1` (schema line14622), `record_permission_v1` (line15301) and `ediel_current_retention_companies_v1` (line42378) allow only `active/archived/pending_deletion`. Their later migration adaptations add current Auth/class/read/clock behavior and retain this status restriction. The real HTTP workspace parser `lib/ediel/retention/retentionHttp.ts:30` uses the same three-status enum.

Consequently, even an otherwise current accepted member with explicit own operation/class grants, exact legal issuer/deadline/source and separate reviewer cannot submit/read/review/purge via the class path once the actual terminal tenant close has committed. A lawful retention deadline can expire after operational closure; indefinite retention cannot be repaired by reactivation because the actual closed state is terminal. Neither DB-owner manual mutation nor caller authority flags count as the required decided class workflow. This is a source-proven unhandled applicable scenario; the reviewer did not execute or label a runtime RED. The author retains the real coupled reproduction and implementation boundary.

Smallest required probe: use the existing actual native close and existing authenticated retention producer/helper, then qualify an exact finite legal policy/current separate reviewer for the same retained customer or original class after close. Assert the intended class action succeeds after its deadline while ordinary operational permission stays denied, wrong company/current DENY/absent legal basis remain held, and original journal/settlement/source hashes outside that class remain unchanged. An initial actual 42501 denial on this otherwise-qualified closed tuple establishes RED. No opaque capability, source approval, disabled trigger or DB-owner purge may substitute.

If confirmed, minimal forward scope is the three existing retention-local SQL status predicates plus the bounded HTTP status DTO. Preserve OIDs/signatures/owners/ACLs/configuration, all accepted-member/current-actor/class/DENY/legal/source/reviewer/clock/lock behavior, and operational closed denial. Do not rewrite admitted historical migrations or broaden global tenant authority.

## False positives and admission limits

The earlier 10a canonical disposable path was repaired in93f and now has genuine native negative proof. Omitted message/meter/export categories alone are not a current cascade finding: actual company FKs for ediel_messages, metering_values, audit_logs, outbound_requests, partner_exports, authorizations and switch/data requests use NO ACTION; registered inbound originals additionally have a DELETE guard. Canonical audit/domain/command/outbox use CASCADE, but disposable test cleanup itself emits lifecycle journals, so category absence alone does not prove unlawful loss. No all-category gate is invented.

Current guard migration SHA256 is `ed92e54ee5c21c781d1e06260e5e7b0a1569ec2896f9e7af0b95f61f3dc5bc3d`, matching its current manifest entry. The new guard functions/triggers are not yet in the checked-in schema capture. This is an admission/capture task for root, not proof that canonical native replay omitted the migration: native current enabled guards and changed status refusal demonstrate application. Admit only the final qualified author head/checksum/prefix; regenerate genuine schema/types/fingerprint and compose current manifests under root ownership. Preserve inherited proofs/source pins and qualify raw9+10 current script inputs. Current successful clean replay is not upgrade, combined future prefix, ordinary mandatory CI, market custody or production acceptance.

Skill routing: repository spec-to-code-compliance, differential-review, verification-before-completion and fp-check; Supabase authority/ACL/source analysis only. Broad/security/performance scanners, DB-04 query-plan work, implementation and test execution are outside this allocated read-only rule review.

