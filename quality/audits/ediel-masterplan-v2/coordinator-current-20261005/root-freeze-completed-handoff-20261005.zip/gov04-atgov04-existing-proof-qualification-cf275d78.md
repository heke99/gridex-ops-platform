# GOV04 / AT-GOV04 existing-proof qualification

Read-only at actual main `cf275d78d252bdaa8e49fb4e5f65afaa61bf0128` / tree `80d5b295ceae1c65b57b924a42e259897b5412cd`, retained root503 `c5afbda9519aa4d0db1ea3f339fddbb8f95f16f4` / tree `19101e4c10ce05641b748ed64df9338c5b2fe29b`. GOV04 remains NOT_VERIFIED; AT-GOV04 and supporting SC064 remain NOT_EXECUTED. No row or source edits and no new claim.

**Recommendation: existing-owner whole-union review, with zero new mandatory behavior cases identified.** The old missing current-worker/history assertion in #4915984791806 is now present in #561's SC051 final case. Its actual queued worker evaluates September25-A-3 then October25-A-4, preserves original E5SE5A bytes/hash and prior decision, records a scoped failed attempt and reaches no provider. Original-source denial is a declared finite RPC port; it is not a native positive source birth. Raw8-case JUnit SHA`edd6f89f5cc505174390f2dab20859f0abf0aabf5dfe58650274b6adb9b66942` has0fail/error/skip; original whole50005 and exact cf source-carry decisions are retained.

| Frozen effect | Existing asserting evidence |
|---|---|
| Current guide before send and fresh version-boundary assessment | SC051 actual sender/worker case163 plus actual registry/admission contrasts |
| Preserve old payload/attempt/decision history | SC051 retains prior decision/original; TR05 native170 preserves real prior attempt, retrieved MIME, archive rows/raw/hash after actual worker retry |
| Block when policy/route/right changes | TR05 actual queued network withdrawal, guide retirement, actor/POA denial; SC051 current source hold; SC064 explicitly permits blocking |
| No old queue payload relabelled into a current send | SC051 source/hash unchanged and provider0; current sender requires matching protected original pack before binding actual admissionDecision |
| Divergent resend only with valid bilateral permission | Current-only acceptedOutbound and existing old-outbound-guide rejection. No optional old-guide exception/grant is enabled or claimed |

The bilateral clause is a restriction, not an obligation to invent a grant for an old guide. Existing subtype/customer bilateral sources authorize their own scopes; they do not establish version-deviation permission. If the retained owner claims a supported old-guide deviation, that exact existing agreement/version authority and positive/invalid contrasts must be qualified first. No such new claim is made here.

TR05 raw d4 archive SHA`6b865270909fb8db03155316e25bd6a302f59258aef201806f09ab5c6276a5c1` / run37244708321 / job111560181612 / artifact11319786242 rechecked:28PASS,17TR05,0fail/error/skip; all9 receipt source hashes match d4. Its producer remains exact root. Current root worker delta versus main affects alreadyClaimed lease and post-success projection; SC051 uses ordinary claim and stops before those branches. Sender's d4→current UNOC guard/encoder delta is explicit; existing native evidence is not relabelled as a current503 native run.

A same-original genuine private old-guide birth/attempt through a different current-guide DB prefix remains NOT_EXECUTED. This remains a native integration boundary, not a new mandatory criterion imposed on bounded code effects. SMTP post-acceptance fixtures mock admission and cannot supply that authority.

Retained GOV04 owner (#4915984623767/5984791806) should review this exact collective proof and propose its own GOV04/AT existing-file annotation/evidence carry only if satisfied. Root503 retains TR worker/history; ten08_rule_review/#561 retains its scenario. Supporting SC064 is reuse only. No sender/journal/harness rewrite or new native execution is justified by the old now-covered gap. Final current gates and whole-row decision remain with the retained owners/root.

Complete source hashes and provenance are in the JSON. Dedicated checkout is clean. Only these own immutable checkpoints were written; no tests/native/CI/SQL/source/coverage/shared-memory/GitHub analysis actions. Private IMP05 export block is untouched.
