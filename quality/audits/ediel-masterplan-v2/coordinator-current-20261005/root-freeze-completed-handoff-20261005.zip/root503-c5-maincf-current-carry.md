# Root503 frozen c5 — future maincf carry

**APPROVE source/input/raw-import carry; memory resolution remains required.** Frozen c5 `c5afbda9519aa4d0db1ea3f339fddbb8f95f16f4` / tree `19101e4c` and main `cf275d78` have one conflict: `.agent-memory/handover.md`. Actual merge-tree exits1; its full-reference tentative tree `efa8cfae` contains markers and is not merge-ready.

A read-only proposal removes only the three marker lines and retains both conflict blocks verbatim, root then main, preserving every nonempty parent line and every other byte. Conditional expected resolved union: **`3a475f5bad5b8d03f7904159270a560afd121d18`**. Handover blob `b85985180dc09d376c3ceaef7e3978d0c2a006f7`, SHA256 `13a78929ae596a590b94bc725b1d34d558524f0f4049cdf79c39d4ea6c4f9b2e`. Reference spelling changes only tentative marker labels.

All 13 existing root source/workflow deltas from main, app/lib and migration tree are exact authentic producer5be. Eight replay inputs remain approved: seven producer bytes and manifest metadata `e2ed39c6`. Existing generated types/schema/fingerprint remain exact raw5be import; no new capture is needed by this main delta and no producer attribution or NOT_RUN flag is relabelled.

All 352 IDs/order/main metadata and 346 foreign rows with ordered evidence are exact. Current SC034 PASSED and SC047 PARTIAL evidence, source-safe588 additions and root's six rows are preserved; main224 → conditional candidate230. New Z06F/G proposals remain outside native registration.

JSON SHA256: `3e74a38f41be7aa9cfd0c1597ef90e31dc7d713bd00f7933293d9b14cb8efac4`. No test/native/capture/tagger/full review was repeated. Only own isolated Git objects and temporary review index were used; frozen c5 checkout/index/source/generated/memory and CI remain untouched. Root owns future memory resolution, actual-main guard, publication and current-head gates.

