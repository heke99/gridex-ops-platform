# SC009/SC019 — mainb7 minimum carry

**APPROVE** #544 exact4e6b against main b7a2daa3. Expected clean union **3e0a9068188996d7c65efe900f366701076f065f**.

The sole #591 delta adds one AT-P04 ordinary test, own checkpoint/records and its PASSED row. All production, schema, migrations, scripts, workflows and capture inputs remain unchanged; 29 selected source pins and 23 complete SQL definitions retain prior qualification.

All 352 IDs/order/metadata and 350 foreign rows with ordered evidence are exact. Only SC009/SC019 differ: main225 → union227. Every foreign main blob is retained. Prior whole-literal/raw32/finite DB06/native limits are unchanged. No run or source review was repeated; root's actual nine-green snapshot is reused. Root owns guarded merge/publication.
