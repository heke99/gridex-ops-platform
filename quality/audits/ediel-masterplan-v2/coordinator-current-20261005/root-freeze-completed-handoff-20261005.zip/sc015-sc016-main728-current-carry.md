# #559 current main728 carry

APPROVE minimal source and 350 foreign-row carry for `234f76b9383b7d56a15018dbbbe46a2d79e84654` against actual `728e4f99bf13fae5ead9678f9a2931a298f94e0d`. Expected clean union tree `1e2df721fc5f60d88f09be6ae70f3628dd9bc5df`; approved count227→229, only SC015/SC016 change. Exact main parents863+4e98 and tree57e7c123 are verified.

#593 adds42 own test/proof/checkpoint paths and changes one production file: `lib/ediel/flows/inboundBusinessStateMachineLegacy.ts`, SHA2569d0146c9. Exact reconstruction proves it only removes the private strictUpdate helper and its sole Z02 information outcome customer_info_requests cached status/snapshot writer, adding three comments. Every other source byte is preserved. The unchanged canonical selector maps this outcome only from Z02 L/LK record_grid_contract_response. Protected atomic core/linker, permission and non-Z02 branches, policy/authorization/SQL/schema/migration/capture inputs are unchanged.

SC015 outbound command and SC016 explicit module consumers exclude this Z02 projection. General inbound can reach Legacy, where permission and ACK/supply slices remain exact. All32 selected CF pins (including previously qualified SC02016-line fixture), complete25 SQL definitions/attributes via schema identity and eight capture inputs remain exact. All352 frozen IDs/order, metadata, all350 foreign rows/ordered evidence, owned evidence unions and foreign main blobs survive.

For future561, no selected technical input intersects this source delta; UTILTS facade bypasses Legacy. Future root d5 adoption must explicitly retain this added Legacy delta rather than claim entire app/lib identity with5be. The unchanged capture/migration inputs require no new capture from this change alone; current type-manifest metadata review remains separately owned. No future561/root union or CI approval is given here.

The inherited #593 independent finite71 and whole-NOT_EXEC boundaries and original #559 finite IO/native limits remain. No tests/native/capture/whole review reruns, CI repoll or owner mutation. Root owns fresh-main guarded merge/publication.

JSON SHA256 `2e307df2813842876ccc64224a2404ba376a32cf6e80bb93fe999ee1b646a821`.
