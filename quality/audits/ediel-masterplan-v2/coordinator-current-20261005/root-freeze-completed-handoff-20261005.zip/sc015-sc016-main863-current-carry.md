# #559 current-main carry

APPROVE source and 350 foreign-row preservation for frozen `234f76b9383b7d56a15018dbbbe46a2d79e84654` against actual main `863806547821e92f37aad866261123882810e37e` (genuine #544 parents verified). Expected clean union tree `2c06bab1c2fa8bdf95362af1764cc27a68543eda`.

The 38 new main paths since qualified CF are #591/#544 ordinary tests, test scripts, own records and three promoted ledger rows. None intersects the 32 selected paths; no production, schema, migration, workflow or capture input changed. All 31 original pins and the previously qualified 16-line SC020 administration fixture delta are exact. Whole schema identity preserves the 25 complete selected SQL definitions and attributes; eight authentic capture input pins remain exact.

All 352 IDs/order and main metadata, all 350 foreign complete rows and ordered evidence, every foreign main blob and owned evidence unions survive. Main 227 → union 229; only SC015/SC016 change.

Root supplied the exact-head nine-green plus CodeRabbit snapshot. No test/native/capture/whole review rerun, CI repoll or owner mutation. Original cde whole proof and finite IO/native limits remain. Root owns actual guarded merge/publication.

JSON SHA-256: `83f9be299706cb13faa40817012973eb8b4d394eb76f6ef741ee187cab57470f`.
