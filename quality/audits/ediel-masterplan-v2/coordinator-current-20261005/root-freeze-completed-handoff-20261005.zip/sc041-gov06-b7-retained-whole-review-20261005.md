# Retained whole-card review: SC041 and GOV06/AT

Read-only reviewer `/root/sc015_sc016_gate_failure`; sole Claude magical-einstein source/carry allocation preserved. No owner/code/test/coverage changes or new tests, native/full runs, CI poll, workflow or public technical writes. Root owns public batch and merge.

Actual main `b7a2daa3627f1f8f56055681ba5a8d78e902ad55` / tree `bddfea4e8f6e2cb0c49629715de8b2f94448bf6a`. Current #513 `7eb5faa09ebee5a72a7415eaa7c85c00ce063ed1`; current #521 `c1cac7c0ee253bab2fc53ff308517498b13cee92`. Prior cf and original665/b740/8fc remain immutable historical pins.

## SC041

**All literal source/effect clauses mapped; original independent whole-approval custody unresolved.** Existing genuine PRODAT/APERAK/CONTRL builder/codec proof checks UNB0031, AB/NA independence, generated CONTRL:2:2:UN first4components, no new request/wait/timer and no_ack_required. Complete script is byte-exact original665→current7eb, all old assertions retained, optional fifth qualifier preserved. Current-main codec adds UNOC preconditions but actual serializeUnb remains byte-exact; finite VM/helper and frozen source/UNSM custody pins retain scope.

Original owner [5984158806](https://github.com/heke99/gridex-ops-platform/pull/491#issuecomment-5984158806) and PR513 body report implementer64/64+separate parent64/64. [5984074107](https://github.com/heke99/gridex-ops-platform/pull/491#issuecomment-5984074107) names independent complete SC matrix. No independently authored source/head-bound whole APPROVE or corresponding raw parent64/input binding located; formal PR reviews are empty. This is approval custody, no proved new functional failure. Root/retained owner must resolve that exact original receipt or separately qualify current whole approval. Reader does not duplicate implementation or execution.

## GOV06 and AT

**Genuine original whole APPROVE and source carry qualified; preserve one historical evidence pointer in each own row.** Root [5984823508](https://github.com/heke99/gridex-ops-platform/pull/491#issuecomment-5984823508) explicitly approved correctedb740 after123/123 across10 existing files. Separate anchors, same-policy actual runtime reuse, all9 absent/incoherent denials before matching/link/write, no invented national field error, physical syntax precedence and detached diagnostics are complete. Earlier guard-order/missing-anchor failures remain historical with their corrected receipts.

The two production files plus strengthened processor test remain byte-exact b740→8fc→currentc1. Real resolver/part-2/nonbilling/fixtures are exact. Preserve current OPS05 report propagation, U19 correctpoint linking and typed actor/permission refusals. Current-main engine/initial owner lack only exact approved coherence guard+import and one presence line; no new source correction is needed.

## Actual-main composition

Maincf→b7 integrates #591 test/evidence/AT-P04row only, zero product source changes. Both raw merge-trees are conflict-free and preserve all foreign main rows/blobs, ledger metadata/order and published owned evidence.

| Packet | Expected raw tree | Foreign rows equal | Main blobs retained | Approvals | Main own evidence union |
|---|---|---:|---:|---:|---|
| #513 | `59ded15cfb22ea7534e3525734ceb61ee4011c87` | 351/351 | 7820 | 225→226 | complete |
| #521 | `9a79d41a3d5b734add2365e490cc1a2e8b4c5edf` | 350/350 | 7818 | 225→227 | baseline pointer missing in2ownrows |

Raw #521 omits existing `quality/audits/ediel-masterplan-v2/context.md` from both GOV06/AT-GOV06 evidence arrays; original promotion already replaced that baseline pointer. This is the only detected row preservation shortfall. Sole Claude/root writer should retain the pointer once in each own row. No reader edit.

Accompanying JSON pins full literal frozen rows, actual commit trees/parents, source SHA256s, proof comment text/hash and preservation counts. These focused pins are not a full dynamic import closure. Historical123/64 claims keep original scope, no new execution is inferred. Root still owns fresh actual-head CI and expected-head current-main integration after pointer repair/latermain advance. No third-card approval or production/native/market claim.
