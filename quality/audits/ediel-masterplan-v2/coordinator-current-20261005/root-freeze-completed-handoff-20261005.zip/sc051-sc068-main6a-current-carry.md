# #561 SC051/SC068 actual-main carry

APPROVE source and350 foreign-row carry for frozen `16e7c71d8f307cf193a5ef14be6b5aad9db8d74c` against actual main `6a42223d1adfe48c773ab9a1bf5ab9ae8fdc9806` (parents728+234; tree1e2df721). Expected conflict-free union tree `61514f9decc25ebb2ae1c31705be81a47ac0efa5`. Main229 → union231; only SC051/SC068 change.

All50 previously whole-approved technical source pins are exact at head and union; the complete schema remains byte-identical, preserving12 selected complete SQL definitions/attributes. Eight authentic capture input pins remain exact. Current-main #593 Legacy9d0146c9 removal is explicitly retained with its existing scoped source qualification: private strictUpdate and its sole Z02 L/LK cached snapshot writer only, all other executable slices unchanged. No selected input intersects; UTILTS facade bypasses Legacy and non-Z02 paths remain exact. This is a production change and is not described as whole production-tree identity.

All352 IDs/frozen order and metadata, all350 complete foreign rows and ordered evidence, owned evidence unions and all foreign main blobs are preserved. #559 diagnostics and #593 source/evidence survive byte-exact.

Original whole50005 and finite native/SQL/reference limitations remain, including synthetic TEST wire, no authentic market/native-prefix/RLS or SMTP witness and no blanket zero-write claim. Existing #593 finite71/whole-NOT_EXEC boundaries remain. No tests/native/capture/whole rerun or CI repoll; root owns actual head/main/nine-green plus CodeRabbit guarded merge and publication.

JSON SHA256 `5c71656538fb7c82b8afb54ed68f9ae091e4b953c518620ba9eb6b5cba5a2992`.
