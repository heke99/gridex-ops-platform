# Root503 + main845 composed runtime verification

**PASS142/142 in7/7 suites**, zero failures/skips, one11.18s run. Exact genuine merge `9ecf42395120aa883073856995678c1cac643cc8`, tree `e1a9f5d478dd7356b0d22b7a9ea4e1b31c29c2df`, parents root913 and main845. The expected tree matches. Independent clone and source remain clean; frozen root preview/shared refs untouched.

New GOV06 production deltas require retained time anchors in initial canonical UTILTS validation and check their source/time coherence in the real engine. The four named affected UTILTS suites, root PRODAT recovery consumer/gateway and SC001-selected actual `ediel-utilts-persistence-processor.test.ts` ran once on the composition. That caller executes real processor/engine plus later canonical dispatcher with declared IO through contracts/storage/ACK. No test rewrites or source fixes were needed.

Node22.23.3, existing loopback network boundary, two workers. Exact per-suite counts, source/test blobs and SHA256 values, command, raw log and JUnit hashes are in the sibling JSON. This is bounded unit integration proof on the exact composition; native/replay/capture/full and root required CI were not rerun or relabeled. Root retains final adoption/merge/CI.
