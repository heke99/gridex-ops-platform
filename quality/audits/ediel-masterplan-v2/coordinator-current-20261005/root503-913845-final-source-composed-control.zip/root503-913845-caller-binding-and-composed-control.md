# #503913 / main845 actual caller binding and composed control

APPROVE bounded caller integration at expected merge tree `e1a9f5d478dd7356b0d22b7a9ea4e1b31c29c2df`, with the separate one-time composed142/142PASS,7files,0failure/skip/exit0 at isolated genuine913+845 commit9ecf4239. This is a rehearsal tree, not an actual remote merge. Prior source/ledger/capture guard remains immutable; frozen913 is untouched.

Actual root inboundProcessing328 resolves the opaque decision;1206–1207 passes the same policy and full decision through the stable utiltsDataRequest facade into the real canonical dispatcher247. Dispatcher262–263 and part-2:389/399 retain that pair and check real source policy/time context before matching/linking/effects. MessagePolicy129/153 always constructs supported operative policies with frozen anchors from actual receive/created time and wire; missing admission is already rejected. No legitimate inspected root path manufactures a bare operative policy. Protected NULL-company intake and unresolved tenant return first, and PRODAT recovery explicitly requires PRODAT. Status/parse metadata updates do not request a receive/raw timestamp rewrite; real DB re-fetch coherence remains an external boundary.

The selected real caller suite is ediel-utilts-persistence-processor.test.ts: real processor/engine/canonical validation/contracts/storage/ACK and actual nonbilling dispatcher, with declared IO. Separate decision-reuse mocks part-2 and would not alone cover the effect boundary. SC004 alone ran the fixed four GOV06 suites, two root recovery suites and this single53-case caller, yielding142PASS; no rerun occurred here. Raw logs/JUnit/pre-inputs are hash-verified against SC004 immutable receiptbedb8a29.

Exact142 control does not establish native private7forwards/trigger/RLS/SMTP custody or relabel frozen913 pending clean replay. Root owns latestmain/head/CodeRabbit/nine-gate guard and actual merge. No source/test/memory/index write, push/merge/lease or99/58/full/native duplication.

JSON SHA256 `1a7403b88fbcec62bf9584c325b14e2710be1296345579da5e24e65b33933c2f`.
