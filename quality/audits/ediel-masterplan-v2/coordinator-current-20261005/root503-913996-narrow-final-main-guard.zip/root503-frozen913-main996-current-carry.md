# Root503 frozen913 / actual main996 narrow documentation carry

**APPROVE the documentation-only source/input/ledger carry, with the known SC068 RED boundary retained.** This is a predicted-tree qualification, not an actual merge, CI result or globalgreen claim.

- Frozen published #503: `9132a6ed4649e8b17aba4270417c649939c3e0c4` / tree `44ce48b1e0aa47b68a273af1d92196670e01c663`.
- Actual main: `99676683338e11e60666345782609a822de9181e` / tree `0b1d98ccac00c4cb84e2385bcfc44c09d693fc42`; genuine parents `1aeccc7cc92c10c8e6781026e42e834d25023802` + `d51028b12c1a43184ef35da1f3ec0f7c1a8c9076` (#602). #601 has genuine parents `8451f013837c8b4b198ad2c5490cc2a54ab847ff` + `3ced652fbe3e7e13f2411a0bec4a5754c7c53d9f`.
- Ordinary merge parents **main996 + frozen913** predict **`dd4aba7be5ca034e288d53e595d28b744cf7a8c8`**, merge-tree exit0 and no conflict. Nothing is merged or adopted by this reviewer.
- Prior source carry `root503-frozen913-main845-current-carry.json` remains untouched, SHA256 `b2f7b76993bd1cdce81f30e91fe2860db2cbcd2a82c17a136bfba231fe82d816`. The new union differs from its qualified `e1a9f5d478dd7356b0d22b7a9ea4e1b31c29c2df` tree in exactly the five #601/#602 documentation paths below. Every other blob and mode is exact.

| Changed path | Input/effect |
|---|---|
| `.agent-memory/masterplan-at-z06f-z06g-supplier-checkpoint.md` | Post-merge owner checkpoint; no executable or ledger input. |
| `.agent-memory/masterplan-at-z15v-z15vh-esco-checkpoint.md` | Post-merge owner checkpoint; no executable or ledger input. |
| `quality/audits/ediel-masterplan-v2/at-z06f-z06g-supplier/postmerge-receipt.json` | Finite owner post-merge receipt; documentation only, no new approval row. |
| `quality/audits/ediel-masterplan-v2/at-z15v-z15vh-esco/post-merge-receipt.json` | Finite owner post-merge receipt; documentation only, no new approval row. |
| `quality/audits/ediel-masterplan-v2/sc010-sc071/integration-status.md` | Owner integration-status documentation; no asserting test/source change. |

All 346 foreign **complete rows, ordered evidence and row order**, all352 IDs and main metadata remain exact currentmain. The six root rows TR-05/TR-10/AT-TR-05/AT-TR-10/SC-040/SC-063 remain complete frozen913 rows, preserving current-main evidence. Main254 PASSED/VERIFIED → projectedunion260. The ledger is byte-exact the prior845 union.

The 13 root source pins remain exact authentic5be/frozen913. F3's preapproved gate/test pair, every other production/asserting test/caller/SQL/workflow/generator blob, rawgenerated3 and all8 capture inputs remain exact the qualified prior union. The migration tree is `400fe39e86fc8f7fe89f87ff70e84c24a1b1b88e` with **1074 files /1073 SQL**, preserving all seven existing root forwards. The eighth capture input retains only its separately approved d5 origin-metadata correction; no repeat custody review.

Authentic capture stays producer `5be3a902a61309e295d1f3b82f5ceb0996edb1dd` / run37319901610 / job111796010070 / artifact11351030885. RawZIP and rawreceipt retain their qualified blobs and original native/browser/type-schema-comparison/upgrade-parity **NOT_RUN** flags. No documentation change requires new authentic capture, and the current main/union is not relabelled as producer.

The once-only 142/142, seven-suite composed control remains its original rehearsal9ecf/treee1a and receipt `bedb8a2974d5e863a2c308ed0c5b153c8ffc50d0947b1f65af47121a01318125`. Its suites and reached source blobs remain exact; it is not rerun or described as covering other suites/native IO.

**Known boundary:** two current-main SC068 fixture REDs remain outside that142 suite set. Their correction belongs exclusively to GOV01 authora7eb3a1. Peer publication7b3f041afa20b598be663e8c13f5ea2261176c73 is not adopted by main996/frozen913 and is not reviewed here. No globalgreen claim or fix is made.

Common root memory remains frozen913. Root's later601/602 common-handover append is outside this exact predicted tree. No source/index/shared-ref/coverage/memory edit, push/merge, new card/lease, test142/99/58/full/native/capture rerun or CI scan. Root retains actual fresh head/main/current9+CodeRabbit gates and publication; peer609/531 ownership is untouched.
