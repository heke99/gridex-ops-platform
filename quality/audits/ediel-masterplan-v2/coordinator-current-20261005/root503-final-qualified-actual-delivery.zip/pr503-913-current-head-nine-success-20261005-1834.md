# PR #503 current-head CI qualification

Observed 2026-10-05 18:34:20 UTC by the sole read-only observer.

Exact published head `9132a6ed4649e8b17aba4270417c649939c3e0c4`, tree `44ce48b1e0aa47b68a273af1d92196670e01c663`. All nine mandatory jobs actually completed SUCCESS. The final clean replay job 111888126963 (OPS run 37347049406) completed at 18:31:33 UTC; its clean, redaction, upload and completion steps all passed. CodeRabbit status 55624881619 is SUCCESS with the descriptor “Review skipped: manual review required for this OSS repository”; this does not supply an authored code review.

The completed clean job's actual checkout reports this exact head. Runtime phase markers reached native owners complete at 18:21:22, browser complete at 18:30:06, after-browser native complete at 18:30:58 and schema gates complete at 18:31:06. The actual tenant gate emitted “Tenant isolation invariants: all checks passed.” once, parity selftest emitted its required drift-class PASS once, and schema verification emitted fingerprint `9e2db4c7fc4f3a4e3d96e60019bad403400dd44913f0241f07fb7d1be7881b74`. Generated types SHA `88cf7de264a01c68ba51d6b57f69aac451068cabc0f20f88362d748793ce7b5e` matches the committed types and manifest. The verified schema fingerprint also matches the committed fingerprint and manifest. Printed shell source was excluded before counting runtime native/type failure assignments: both are zero.

The actual blocking F3 execution qualifies the replay rows against the reviewed birth predicate, actual event/source foreign keys and matching unresolved environment. Other tenant NULL rows remain rejected. We do not infer/export individual historical nineteen UUIDs or an unobserved current row count. The original c5 failed job 111823068862/run37327659342 and receipt `f587cf0ebd6ceea3d41714c081d3d332c5d40278694bd796daeb26244d45f4e8` remain historical failure evidence. The independently reviewed 58 finite cases remain separate evidence.

Actual native run summaries retain skip counts: the first Vitest group reports 54 files passed, 673 tests passed and 1 skipped. Later wrappers include 5 passed/1 skipped and an after-browser group with 1 passed/5 skipped. These are not relabeled zero skips or expanded into invented inner assertions. The unchanged mandatory gate has passed its blocking logic.

Existing current-head upgrade job 111888126938 completed SUCCESS and emitted the genuine ancestor → forward-only checksummed upgrade == independently clean schema/types PASS, with retained-source comparison and actual schema/fingerprint/type/manifest comparisons before that terminal. Historical capture-only provenance and NOT_RUN flags remain immutable.

No source edit, local test/native run, workflow dispatch/rerun/cancel, artifact download, foreign job read, GitHub write, private raw-log export or merge occurred. Only bounded parsed metadata from completed logs is saved. All exact job IDs, timestamps, step results and source hashes are in the companion JSON. Root owns fresh main/head/all-nine/ordinary expected-tree guards and merge; unrelated main/PR609 failures and merge completion are outside this receipt.

