# Root503 frozen913 / actual main8a — #604/#605 narrow carry

**APPROVE the owner-qualified source/input/foreign-ledger carry, retaining the known SC068 RED boundary.** This is a source/expected-tree guard, not a503 merge, CI result or globalgreen claim.

Actual main `8a072448f2b6a1d77e9dad343f4cb07136ac7260` / tree `0176b380b4909307982b4cfa0f5d91d3c78d5d27` has genuine #605 parents `737f48438e8ba806c34882988b5feadaaeb0369e` + `7397c48913fef494840d6227c59535d79b3cd56c`. Earlier #604 `737f48438e8ba806c34882988b5feadaaeb0369e` has genuine parents `99676683338e11e60666345782609a822de9181e` + `29f3ba39f07f624ad8b0d2b6424b94df7ade49a0` and exact published tree `ccc88ffeb62572aebcd93891f5adfc7774af0ae6`. Fresh API and isolated private Git fetch agree.

Ordinary parents **main8a + frozen #503 `9132a6ed4649e8b17aba4270417c649939c3e0c4`** predict **`14729bfdbe56f67149d51e227e25d7274aa4025e`**, merge-tree exit0, no conflicts. No adoption or intermediate737 artifact is claimed. Historical996 receipt remains immutable, SHA256 `87d941ab90f117a856c5c2ec7498365bc1e218a397de9731016bba904bf6e7fe`.

The predicted union differs from qualified previous `dd4aba7be5ca034e288d53e595d28b744cf7a8c8` in exactly11 owner paths:3 from604 and8 from605. Every new path is byte/mode-exact actualmain and its reviewed owner head; every other prior-union blob/mode is exact.

| Production path | Actual input/effect |
|---|---|
| `app/api/v1/website/public-contracts/route.ts` | Capture resolved tenant reference inside the existing request-local concurrent tenant promise, preserving reference on later offer failure; authentication/ETag/parallelism unchanged. Not imported by root entrypoints. |
| `app/api/webhooks/manual-inbound/route.ts` | Escape literal email backslash/percent/underscore in existing verified mailbox ILIKE filters; existing signed webhook path/call unchanged. |
| `lib/customer-operations/facilityResponseOrchestrator.ts` | Forward existing input to canonical completion with triggerNextStep:false. Only after successful completion, wrap failing intake/supplier/workflow/event continuation with typed actual result/scope/cause; ordinary rejected completion unchanged. |
| `lib/customer-operations/manualFacilityResponseParser.ts` | Actual completion rejection remains review/applied:false. Only scoped typed successful post-commit error retains completion/applied state and records continuation review; unrelated error follows existing failure path. |
| `lib/facility/facilityLookupWorkflow.ts` | Actual completion RPC error/result guards precede marker construction; add exact request identity guard. Retain real successful result/cause/scope for ancillary post-commit failures; no fabricated success/status reread or SQL input change. |
| `lib/inbound-mail/manualInboundCorrelation.ts` | Escape literal sender email; verify both case and reply bindings; recipient equality needs same-request/company reply; conflicting bindings become ambiguous and cannot authorize application. Existing verified contact model retained. |
| `lib/inbound-mail/manualInboundIngestion.ts` | Only matched correlation supplies operational/entity attribution. Canonical completion owns terminal request state; ingestion finalizes its inbound projection rather than issuing a stale-status second request update. |

Each author test/checkpoint is pinned separately in JSON. Existing reviewed29f real-route10/independent proof and7397 full-path52/types/lint/combined324 source-composition GO are reused, as public530 comments6000540851/6000581848 record. Neither author's proof is rerun or extended.

Actual conservative literal import/export/dynamic-import closure of **all12 TypeScript root13 entrypoints** resolves **700 local modules**, including type imports, with **0 unresolved local literal imports**. It reaches **none** of604/605's seven changed production paths. All700 module blobs are exact the previous qualified union. The changed605 caller chain is signed manual webhook/mailbox poller→manual ingestion→parser→orchestrator→facility adapter; separate admin facility/website actions call that orchestrator. There is no root13/Ediel literal import into the changed605 files. Static closure does not claim externally injected/computed imports or global runtime behavior.

All346 foreign **complete rows and ordered evidence**, all352 IDs/order and actual-main metadata remain exact. Root's six complete rows remain frozen913, preserving current-main evidence. Main254 → projectedunion260 PASSED/VERIFIED;604/605 make no ledger promotion. Root13, F3 gate/test/readset, generated3, approved d5 metadata and capture8 remain exact prior qualified union. Migration tree `400fe39e86fc8f7fe89f87ff70e84c24a1b1b88e` retains **1074 files /1073 SQL and seven original root forwards**.

Authentic capture remains5be/run37319901610/job111796010070/artifact11351030885 with all four native/browser/type-comparison/upgrade **NOT_RUN** flags. No capture input changed or new capture required; currentmain/union is not the producer. Existing once-only142 composed suite sources remain exact, with declared IO/native limits unchanged.605 proof retains finite Data API/external ports and no native SQL/RLS/successful supplier automation claim.

Two known SC068 fixture REDs remain exclusively GOV01/609 author-owned and unadmitted in this tree; they are outside the142 control. No repair or globalgreen claim. Common memory remains frozen913; root separately records604/605 once. No source/index/shared-ref/ledger/capture/memory edits, push/merge, rule claim, test142/99/58/full/native/capture rerun or CI scan. Root remains sole current9+CodeRabbit/head/freshmain observer and merger.
