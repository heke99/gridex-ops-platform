# OPS03 f458 native-reader interface handoff

Read-only at public #594 `f458dd9c2ff225b023d33ca88acc909f799249df`, tree `3de04cdd30de702e1480178a1cc334751f925aac`; local Git and remote commit metadata agree. Existing OPS03 whole-code approval is not changed. Root owns only the scanner; the retained OPS03 author owns its runner and consumer test. Public metadata handoff: [#5945996580453](https://github.com/heke99/gridex-ops-platform/pull/594#issuecomment-5996580453), reusing prior5305995110582/5995884138/5995927534 and the byte-bound native-tag-consumer design.

## Actual current seam

`scripts/gridex-full-production-e2e.cjs:142` has internal `consumeReviewedCodeEvidence(root, source, blockers, modes)`, called by the release assembler at337. It returns only `caseEvidence` and `ciQualified`. Exhaustive source search finds no `readVerifiedIndividualCaseResults`, `module.exports`, `exports.*` or `require.main` guard. Top-level certificate dispatch starts364; normal runner branch starts384, creates artifact directories and eventually runs steps. Requiring this script is therefore not a safe read-only scanner interface. The existing new test executes the full script in a VM with finite command ports rather than importing an exported function.

The native path at259–265 is fixed to same-candidate `ops-hardening.yml`, successful `clean-migration-replay`, `gridex-rem-002-clean-replay`, `rem002-native-junit.xml` and two source-reviewed DDQ/DGI case bindings. No alternate-workflow or qualification-reference/BASE-plus-forward intake exists. This is an integration scope gap, not evidence that the already reviewed fixed OPS03 channel is defective.

## Existing custody to retain

Lines147–258 validate origin repository, exact candidate commit/tree, immutable whole Git mode/type/blob/path input comparison, latest run/head/path/repositories, positive integer run/attempt identities and the attempt-specific unique successful job. Lines186–214 bind artifact to that repository/head/run and the exact job upload window, verify archive digest and byte size, and read a uniquely named ZIP member without extracting archive paths. XML rejects entities/DOCTYPE, checks parser validity, matches exact classname/name once, and refuses failure/error/skipped selections. Current literal source/helper/config/workflow/document digests all match actual f458 bytes. Self-attested archive/ENV class and scope labels supply no authority.

Current output emits only qualified case aliases and source file hashes. Its generic blocker strings do not structurally distinguish failed, error, skipped, missing and unqualified cases. It does not return exact case name, producer job ID, executed head/tree or selected member path. These identities are checked internally but are needed explicitly in a scanner outcome join. Do not replace them with caller fields or a global success count.

## Smallest retained-owner adaptation

1. Export one read-only function from the existing runner and put existing CLI dispatch behind `require.main === module`, retaining direct execution behavior.
2. Reuse its one authentication/ZIP/JUnit implementation. Return exact normalized file/case outcomes, tested file hash, run/attempt/job/artifact/head/tree/member/digest identities and blockers; retain distinct absent/error/fail/skip/unqualified states.
3. Accept references to existing immutable owner packets only as selectors for a reviewed workflow/case/source binding. They cannot authorize caller JSON, invented ports/classes or `sourceQualified` booleans.
4. For existing BASE-plus-forward proof, retain the actual pinned BASE/tree and effective forward/runtime/test/config source checks and reviewed effects. Example current `ediel-sc071-native.yml:29` explicitly separates BASE replay from subsequent experimental forward; its existing input selector and pre/post evidence are not candidate clean/upgrade/capture parity. Current reader does not consume this path. No new manifest/emitter/runner or broadened parity assertion is needed.
5. The current whole-tree guard also holds an independently changed scanner blob because it is outside four reviewed source exceptions. Qualify that composition through the retained source-review boundary rather than adding an arbitrary content exception.

Root then adds only native discovery and an authenticated outcome join in the scanner. Native files must never be executed by default unit Vitest, and absent/failed/skipped/unqualified evidence cannot become green through the scanner's current absence-from-failed-set rule. Tags, ledger approvals, global GREEN, sibling jobs or orchestrator-step JUnit do not supply native case authority or whole-rule completion.

## Limits and verification

Fresh verification here is source/Git/hash/interface inspection only. The existing consumer suite has finite Git/GitHub/child identity ports and synthetic native JUnit; its real ZIP/hash/XML mechanics do not execute native cases or authenticate a real current-head producer. No test/native/full/CI was duplicated and no genuine current-head native artifact was newly observed. OPS03 document/unit/integration/tenant-E2E/transport/TGT classes and live/formal activation stay separate; this handoff makes no new whole-card verdict.

Source checkout remains clean and unchanged. Only these independent MD/JSON records and the authorized public metadata comment are written. Root coordinates any author implementation and owns scanner/current-source integration.
