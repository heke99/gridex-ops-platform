# Root503 — minimum main7b source/input/import carry

**APPROVE source/input/raw-import carry** of committed root `66774385a98b1e01ec8821ff3d2fd3a415cdf605` / tree `72eec929e8270bb50b09bc86c8b441961bf48736`, adopting actual main `7b158e79ca58fdf7a9b3a77ece035c6b81790bbd` / tree `00612b25336ee545defa14695f439537accd2dde`. Independent conflict-free expected union tree is **`055b059d77c9c634c470b03af14487c218e9ca42`**.

Actual API and Git agree on both main merge parents/trees: #589 `93d6defe` has parents `3dff03dd` + `b7acb387`; #590 `7b158e79` has parents `93d6defe` + `0674fc21`. Each precise owner head has nine actual successful required gates. Incoming delta contains **48 additions**, confined to the two owner packets' checkpoints, three ordinary tests and own plan/quality records. Every previous main blob remains exact; no production, schema, migration, replay, configuration, workflow, common-memory or coverage change is introduced.

Union preserves all 7,868 committed-root paths and all 48 added main paths. All 352 coverage IDs/order/main metadata remain; **346 foreign rows and their ordered evidence** are exact, with only the six existing root-owned rows differing from main. Candidate remains223 versus main217. No TR04 or new owner whole-card promotion occurs.

No new authentic capture is required by this main delta. Union app/lib and migration tree `400fe39e` remain exact authentic producer **`5be3a902` / tree `5c3e101c`**. Seven replay inputs remain raw5be bytes; sole manifest exception is exactly previously approved metadata hash `e2ed39c6`. All seven retained root forwards are exact5be: five older forwards plus current admitted intake `a2d0aa2a` and export `d0e4ec72`. Raw receipt `b6feb364` and generated type/schema/fingerprint hashes `88cf7de2 / 0d733d1e / fee88a98` match committed import and expected union. Independent raw review MD `7c08b681` remains archived byte-exact; approved JSON and finite eight-line TR04 adapter match their original review hashes.

Approved raw-import diff-check d2→667 passes. Root→union diff-check reports three inherited EOF blanks in unchanged #589 review/inventory files; exact main bytes are retained and no foreign normalization is performed. No private inventory content is reproduced.

JSON SHA256: `6222e2ec6ca44dbf8f18a220b63bb223435b8c51bcdd2921f953b4ad7a14d878`. Producer attribution and all four raw NOT_RUN flags remain original5be; this is no current native/browser/parity/whole-runtime or new-head CI approval. No owner edits, test/native/capture execution, push or merge by reviewer. Root retains genuine integration, publication and mandatory current-head gates.

