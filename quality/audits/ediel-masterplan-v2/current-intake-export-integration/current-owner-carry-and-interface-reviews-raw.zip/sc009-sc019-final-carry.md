# SC009 / SC019 — independent minimum current-main carry

**APPROVE minimum source carry** for #544 `4e6b196e9957606d6e05b9259e1a8a2303930be7`, tree `866e87474527463cad630b7a7ead6a3477d5fa0f`, against fresh actual main `3dff03dd8bb8c251b1613d35ce6fc7e66e6ee686`. Genuine parents are approved `7bd40bd` and that main; independent merge-tree is the published tree, without conflicts. Final API refresh confirms the same open published head and main.

The [original entire-scenario approval](https://github.com/heke99/gridex-ops-platform/pull/491#issuecomment-5985411226) is verified against the actual public comment. All three asserting suites equal its `415d9a06` freeze and approved `7bd40bd`, including every assertion. Current main tags are retained. All 7,685 foreign main paths, 350 foreign coverage rows with ordered evidence, all 352 IDs and main metadata are exact. Only SC009/SC019 differ in the ledger; no other approval is created.

Independently verified 23 complete selected SQL definitions, including attributes and bodies, equal original561. Supply/contract/locked-price and qualified legal supply still precede physical-DGI refusal. Of 23 direct selected sources, 20 are exact. Explicit legal62110/transport82150 retains delegation checks despite missing-legal fallback removal; underlay changes are two export modifiers only; real typed denial retains predicates/messages and complete-module imports. No fabricated authorization binding is present.

The receipt gives one input/effect qualification for each of 14 changed reached paths, including the three declared-offset calendar paths and upstream tenant/correlation/certificate/transport boundaries. Fixed15-minute/+0200 wire generators are exact. Seven migrations are additions and do not replace selected SQL owners. Historical native/source origination stays historical; no fresh installed-schema, whole-native, certificate/send, custody/market or positive DGI invoice proof is inferred.

Existing owner raw logs/JUnit hashes independently match: 32/32 in three suites, zero skips; frozen33/121/231; reported types/lint exit0; supported tag352/219approved/242green/0fail. No tests, SQL or native run was repeated. Read-only diff-check passes.

JSON receipt SHA256: `8678f7c1d771a6db35d45b8264b61006c6aaa25511c51f972751449cd13b2d15`. It binds original finite DB06 64TS/50 SQL and #511 three native cases, current raw results, SQL/source hashes, all preservation checks and the GitHub snapshot. Current mandatory CI was queued/pending at the snapshot; CodeRabbit succeeded. **Root must verify all nine actual-head gates and refresh main before merge.** Root owns publication/merge; reviewer made no owner edits, push or merge.

