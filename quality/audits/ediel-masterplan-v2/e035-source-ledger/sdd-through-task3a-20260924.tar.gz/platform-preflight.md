# Platform preparation

Supabase and Postgres skills read. npx --yes supabase@2.101.0 --version succeeded (2.101.0); migration new --help inspected. CLI is cached, no repo dependency changes. Use CLI to create each forward migration; no hosted calls. Native PostgreSQL remains CI-owned.

Official docs checked 2026-09-24: https://supabase.com/changelog (markdown endpoint unsupported content type), https://supabase.com/docs/guides/database/postgres/row-level-security, https://supabase.com/docs/guides/database/functions. Relevant Data API default-grants change: https://supabase.com/changelog/45329-breaking-change-tables-not-exposed-to-data-and-graphql-api-automatically. New private schema tables require explicit revokes/RLS and narrow service RPC EXECUTE; do not rely on defaults. SECURITY DEFINER requires protected search_path and independent tenant/actor checks; public default EXECUTE must be revoked. Do not rewrite global defaults or unrelated schemas.

Task2 read-only contract preflight: /workspace/scratch/4b1d39503015/e035-correction-task2-preflight.md. Sealed source capture is safe initial method; verified PDFs prove bytes/context only, never independent correction cause. Missing retention/authenticated origin must remain unavailable.
