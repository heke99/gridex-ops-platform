## Task 1: Pure earliest-boundary projection

**Files:** Create `lib/ediel/sources/correctionContextImpact.ts`; modify `closureSelection.ts`, `structuralSourceSelection.ts`, `structuralSourceReadset.ts`; test `__tests__/ediel-correction-context-hold.test.ts`.

**Interfaces:** Define `CorrectionScopeV1 = {companyId:string; environment:'test'|'production'; customerId:string|null; objectId:string|null; identityAgency:string|null; legalSender:string|null; legalReceiver:string|null; supplyPeriodId:string|null}`. Define `BoundaryObservation = {kind:'known';utc:string}|{kind:'not_asserted'}|{kind:'unknown'}` and `CorrectionContextBlockerV1 = {version:1; sourceId:string; observedAt:string; scope:CorrectionScopeV1; oldStop:BoundaryObservation; proposedStop:BoundaryObservation; lowerBoundUtc:string|null; reason:string}`. Produce `projectCorrectionContextBlocker(input:{rawC:string|null; oldStop:BoundaryObservation; proposedStop:BoundaryObservation; observedAt:string; sourceId:string; scope:CorrectionScopeV1}):CorrectionContextBlockerV1`. The proposed date is an untrusted *hold hint*, never coverage or a new closure. A genuinely `unknown` potentially earlier boundary makes `lowerBoundUtc:null` even if the other candidate is known; one `known` plus a positively `not_asserted` other candidate can use the known instant. `not_asserted` for a bare C does not mean that an artifact mentioning an unspecified changed end is absent: classify that artifact as `unknown`. Null lower bound means hold the whole matching supply/object interval, not start at the known old stop. Selection consumes `readonly CorrectionContextBlockerV1[]` and returns `structural_correction_context_hold` on overlap. Missing scope components are wildcard matches, never exclusion evidence.

- [ ] Write failing pure tests for old day30/proposed day20 observed day10: day25 interval and day20 current/closing points hold at cutoff day10; day9 saved view does not; prior pre-day20 and unrelated point retain selection. A missing safe lower bound holds the matching whole interval; missing party is wildcard; later proposed day40 still holds from day30. Raw C, BGM5 and rejected/unwitnessed concern cannot become a closure edge.
- [ ] Run `npx vitest run __tests__/ediel-correction-context-hold.test.ts` and confirm the new scenarios fail for missing projection or wrong selection, rather than for fixture setup.
- [ ] Implement the typed projector with the minimum of known instants **only when every other candidate is positively `not_asserted` or known**; any `unknown` candidate yields null lower bound and whole matching interval hold. Validate instants and scope explicitly. Preserve `closureBlockerMatches` and `boundCoverageByClosures` semantics for existing L/LK. The new blocker applies before source comparison; a proposed date is never emitted as accepted `ClosureVersion`.
- [ ] Rerun focused tests and existing closure/structural selection suites. Commit only after the bounded pure behavior is green and independently reviewable.


## Global Constraints

- Start from accepted merged PR371/main `2a148d39d631fc759c99cd1c69350b5e2147dbdb`; final head65f5b896 and OPS35931020643 passed all gates. Preserve merged PR370 closure/retry behavior.
- This is C-PB-1/C-PB-3 hold-only. No positive provenance/basis or C marker, no closure-edge removal, no reopened supply authority, no new market response or quantity.
- Direct agency-9, one physical PRODAT message, post-ledger root is the positive baseline. Unsupported namespace/history stays unavailable.
- Preserve exact source/cutoff and retry immutability. An absent historical record or missing retention coverage is not a negative finding that no rescission occurred.
- Use a new CLI-created forward migration. Do not edit published migrations or generated contracts by hand. No hosted writes, market sends or deployment in this task.
- Source authority is the approved `quality/audits/ediel-masterplan-v2/e035-source-ledger/cancellation-process-basis-design.md` and its amended review. This plan deliberately defers C-PB-2 positive prospective classification.


Task1 is pure blocker/selection/readset plumbing only. Do not introduce SQL, capture UI, positive C markers or external process snapshot acquisition here; Tasks2–4 supply real authority/producers. Preserve existing L/LK and raw-C hold behavior. Caller arrays in pure tests are not production provenance. Follow existing environment type if project differs; do not widen supported environments implicitly. Parent owns memory, publication and CI.
