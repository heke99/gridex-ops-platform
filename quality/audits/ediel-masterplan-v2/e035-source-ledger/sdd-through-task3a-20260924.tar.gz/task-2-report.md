# Sealed Z05 concern capture checkpoint — 2026-09-24

Status: **DONE_WITH_CONCERNS** for the parent-authorized sealed-source-only Task 2 checkpoint. This is not full Task 2, native qualification, merge readiness, correction approval, or completion of E035. Parent owns independent review, ordinary CI, authentic schema/type artifacts, memory and publication.

## Scope and behavior

`captureCorrectionConcernAction` accepts only one company ID, environment, sealed source ID and explicit record-for-review confirmation. It rejects extra/duplicate fields, checks `communication.write` using an all-of requirement, checks operational company state, and obtains the actor from the guard. No caller bytes, hash, reviewer, approval, proposed date or claimed target cross this boundary.

The service calls the append RPC and then a separate witness RPC. It validates source/company/environment/receipt/hash bindings, timestamps including PostgreSQL microseconds, and unreviewed disposition before returning a bounded allowlisted receipt. Interruption, inconsistent receipts or failed witnesses return unconfirmed. Document input explicitly returns `document_context_retention_unresolved`; no PDF bytes or invented retention category were introduced.

Forward migration `20260923231731_ediel_correction_concern_capture.sql` derives observations directly from the existing sealed original. It checks tenant/environment, insert provenance, original hash parity, insertion context, active actor/current company permission and operational company state. The original ledger's insertion trigger is the inbound EDIFACT PRODAT boundary; mutable message state and parsed payload are not evidence. Original-byte storage remains the existing ledger. Source maximum is 2 MiB; the existing bounded 256 KiB wire parser determines whether exact observations can be read, otherwise the concern is wildcard/unknown.

The private exact observational parser uses the existing UNA-aware tokenizer and checks one physical PRODAT/Z05 message, one direct agency-9 object, physical CCI/CAV Z24, envelope/counts, parties, DTM93 and optional LI. Missing LI never invents a target. Unsupported/malformed/multiple objects remain wildcard concerns. Additional text, date or unfamiliar fields keep the proposed boundary unknown. Neither parsing nor a hash authenticates the alleged legal parties or correction cause.

**Parent boundary adjudication:** a C original's DTM93 cannot establish an earlier L/LK boundary. Capture retains this as `observedSourceStop`; `oldStop` is always unknown until a later independent target owner establishes it. A bare C can have `proposedStop:not_asserted`, but the unknown old boundary still requires a whole matching interval hold. `candidateTarget` is null. Customer and supply IDs remain wildcard; mutable message links and LI are never target authority.

Both concern and witness tables have forced RLS, no direct client/service DML or SELECT, and UPDATE/DELETE/TRUNCATE rejection. Narrow service RPCs use private security-definer writers with fixed `pg_catalog` search paths and invoker role wrappers. A witness rejects the append transaction's xid and binds the committed concern/hash/scope. Same original retries return the same immutable concern and witness. V1 has only immutable source-derived facts: changed facts fail explicitly instead of overwriting or falling back to an older revision. Future enrichment/revision owners are outside this checkpoint and must append separately.

## Verification

| Gate | Executed result |
|---|---|
| Initial focused RED | 23 expected failures / 8 passes against the two stubs; null capture and missing guard/witness behavior |
| Capture/action unit suite | 31/31 PASS |
| Node 22 focused capture + Task 1 hold | 35/35 in 2 files PASS |
| Node 22 full Vitest | 6038/6038 in 374 files PASS |
| `tsc --noEmit -p tsconfig.app.json` | PASS |
| `tsc --noEmit -p tsconfig.tests.json` | PASS |
| `tsc --noEmit -p tsconfig.scripts.json` | PASS; rerun after final native additions |
| Scoped ESLint (new TS files and native config) | PASS |
| `scripts/check-migration-versions.cjs` | PASS: 608 files, 512 version groups, all checksums verified |
| `git diff --check` | PASS |
| Native PostgreSQL suite | **NOT EXECUTED** locally; no psql/Docker runtime. Mandatory isolated CI remains pending |
| Generated public RPC types/schema | **PENDING actual native artifacts**; no manual generation or schema edits |

Commands used the supported `npx --yes node@22` runtime (22.23.2). npm emitted the existing environment `http-proxy`/experimental EnvHttpProxyAgent warnings. Initial typecheck identified a receipt type-narrowing error; this was fixed and all three typechecks rerun successfully. Final SQL-only control-character check and checksum update were integrity-checked; SQL execution still awaits native CI.

`ediel-correction-context-native.test.ts` adds **20** cases to the required native config (166 retained + 20 expected = 186). They exercise the real SQL parser and real service append/witness RPCs with synthetic sealed originals: C date cannot narrow an unknown old boundary, no LI, malformed envelope/date/agency, release/UNA behavior, unknown changed date, tenant/environment/actor/permission checks, idempotency, separate transaction witness, forged hash, client/direct DML denial, append-only mutation/truncate, same bytes with distinct provenance, immutable byte/hash protection and operational source deletion/ID reuse. The saved-cutoff cases include a real immutable source snapshot: a committed concern with deliberately omitted witness leaves its original raw C discoverable at a newer cutoff while the saved older readset text/hash stays identical. These are written/typechecked cases, not execution evidence.

Migration SHA-256: `e3c58c78966e88dbf182936ae29df76b25289ffc33bc08a8bf7041cb8cd32e19`.

## Remaining owners

- Document context remains explicitly unresolved in this checkpoint; the independently approved reference-only design is a separate Task 2b.
- No independent original L/LK target is asserted; no positive cause/provenance/reopening owner exists here.
- Task 3 owns bounded process/outbound history; Task 4 owns combined one-MVCC cutoff composition and actual UTILTS hold consumption. This capture checkpoint does not claim that integration.
- Current raw ledger visibility survives a lost witness. No historical backfill, complete old retention claim, market send, hosted database write, deployment or positive C acceptance occurred.

## Skill routing

Applied test-driven-development and writing-good-tests to the service/action boundary, Supabase and Postgres least-privilege/RLS guidance to the forward migration, installed Next `use server` documentation to the authenticated action, and verification-before-completion to the evidence above. Parent-provided written plan/brief and platform-preflight supplied approved source, CLI and current-doc routing. Independent request/receive review and branch completion remain parent gates. Repository-wide mapping/audit, performance, UI/accessibility, supply-chain/static-analysis, skill writing and unrelated refactoring were not triggered by this narrow source-capture implementation. No subagents were spawned.
