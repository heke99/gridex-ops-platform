import { defineConfig } from 'vitest/config'
export default defineConfig({root:'/tmp/gridex-imp05-smtp-probe',resolve:{alias:[{find:'@',replacement:'/workspace/gridex-masterplan-imp03-05'}]},test:{environment:'node',include:['smtp-readiness.test.ts'],setupFiles:['/workspace/gridex-masterplan-imp03-05/__tests__/setup.ts']}})
