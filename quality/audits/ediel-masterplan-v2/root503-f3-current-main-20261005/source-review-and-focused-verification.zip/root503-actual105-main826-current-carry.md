# #503 actual105 / main826 minimum carry

APPROVE source/input and346 foreign-row carry for actual candidate `105b8b87af0b1f02a8f82b869495703fb5ec8d5a`, tree `1aa8738a7c0db47a4ee5754e02f78060c3bb45fe`, genuine parents332065bf+826779dd. Independently reproduced the same conflict-free merge-tree; no memory/test/tag/ledger/source resolution is needed. Main241→candidate247; only the six original root rows differ.

New foreign main packets sincea248 are598/526/516/519/512. Two production deltas are explicit: actor-registry XML now rejects a recognized record lacking all identity fields instead of silently dropping it; UTILTS uses the unchanged prodatDate203 formatter for fixed UTC+1 instants and literal offset-free market times. Exact reconstruction preserves every other byte. Existing serial-owner independent approvals5998772797/5999219018 remain the behavioral authority; no duplicate execution or current native claim. Incoming registry tests, family-release locators and owner checkpoints are exact main.

Preapproved F3 producer10f4 contributes only tenant-isolation-remediation.test.ts and tenant-isolation-invariants.sql; both are byte-exact at actual105. Gate/test finite ports do not confer native private-birth custody/admission/concurrency. Root owns its composed58 once; focused99 and all broad/native/CI runs were not repeated here.

All346 foreign complete rows/ordered evidence, frozen352 IDs/order and current-main metadata, own6 premerge rows/evidence unions and all foreign incoming blobs survive. Four common memory blobs remain byte-exact premerge; all other existing root/main blobs remain within their already approved deltas.

Root13 source, generated3, seven original forwards and migration tree400fe remain exact authentic5be. Capture8 are exact the prior approved manifest/source receipt, including d5 origin metadata. No generator/schema/migration/workflow input changed. Raw37a ZIP/b6fe receipt retain5be/run37319901610/job111796010070/artifact11351030885 and fourNOT_RUN limits; no new capture is required by this code-only/gate-only delta.

This receipt binds exact105; later root documentation commits require source/tree guard rather than invented adoption. No owner/source/index mutation, push/merge/new claim/tests/native/capture/full/CI scan. Root owns publication and current composed gates.

JSON SHA256 `1aa02e8d92cc542ee0fca7ba502ec66a6c5662bccc5eb8a04e2a6ded61140fef`.
