# Root503 one-line native-test trigger source review

**APPROVE exact one-line workflow trigger correction.** Read-only reviewer `/root/sc051_sc068_final_review` inspected root preview HEAD `105b8b87af0b1f02a8f82b869495703fb5ec8d5a` and working `.github/workflows/ediel-masterplan-v2.yml` SHA256 `7b5ccdaa4e0807f03c5fd580f6a4d04492750d5d24a02de4df8bffca02ac513e`.

Exactly one list entry, `scripts/ediel-*.test.ts`, is inserted at line8 immediately after `__tests__/ediel-*.test.ts` in existing `pull_request.paths`. Removing it reproduces every original workflow byte exactly, SHA256 `a77f92d018038e4b863801ddda345f08b2b917f106929798bc175a58b5a568bb`, blob `635786cb71bb65df3d3070a9a67279c04ef9ab9a`. Numstat is1 added/0 removed; diff check0. No semantic gap was identified.

The path matches `scripts/ediel-utilts-err-gateway-native.test.ts`, the diagnosed native-only592 omission. It makes the existing regression workflow eligible for matching PR changes. Every other path, push-main trigger, job/command/assertion, permission, exact-head checkout and source archive control remains byte-exact. This changes trigger coverage; it neither starts a reviewer-owned run nor establishes a native producer, current CI result or whole-card evidence.

Fresh direct GitHub API read confirms retained-author public proposal [5035999057103](https://github.com/heke99/gridex-ops-platform/pull/503#issuecomment-5999057103), including the exact before/after hashes and insertion. Root retains sole workflow application/publication and current-head integration. Reviewer wrote only this immutable MD/JSON, with no source/workflow/test edit, test/native/capture/full/CI run, foreign PR action, GitHub mutation, push or merge.
