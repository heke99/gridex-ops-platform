# PR503 F3 source proposal

Frozen `10f4e393ab63d51cf4c2460f1558f29c4cca9094` / tree `291005c882efca79286e0cfe094dde9faca00ffe` from public preview `6ed80d56f40a0a87178f4a50cc964f9502cd5608`. Exactly the gate and existing remediation test changed; worktree clean. Root retains publication/CI/merge and shared memory.

F3 now recognizes only unchanged `is_birth_v1(m,false)` provenance, then accepts diagnostic children by actual event `ediel_message_id` or unresolved `source_message_id` with the same environment. Missing authority, legacy/NULL raw, wrong/missing/foreign/alternate keys, public flags or business attribution remain rejected. No migration, classification, grants/RLS or any other gate changed.

The unchanged complete gate genuinely fails the two positive cases (56/58 pass); the fix passes58/58, including48 SQL negatives and8 retained application controls. Scoped ESLint, scoped test TypeScript and diff check pass. The selected complete SQL predicate/hash/envelope/lexer and role normalizer execute in PGlite0.3.14; surrounding state is an explicit finite port, not native admission/custody proof. Two earlier test-port setup errors are preserved separately and excluded from RED proof.

Original failure belongs to c5/run37327659342/job111823068862, receipt JSON f587cf0e. Its19 actual rows remain individually **UNKNOWN**. Static unchanged SC014 cases at lines307,340,386,395,449,467,515,534,543,563,622 plausibly retain11 originals. Intake manual_note1 plus explicit case307 process1, case563 process2 and case622 process2+blockedACK1 plausibly retain7 events; case307 creates1 unresolved child. This arithmetic is a source hypothesis, not observed-row identification.

Retention cannot justify a NULL birth tombstone: existing tombstone company is NOT NULL and the qualified transition requires equality to the original company. Legacy arbitrary/noncanonical NULL also has no private birth. Both remain closed. Existing c5 native24/24 proof is reused without rerunning native work.

Full selected source/function/log hashes and exact control boundaries are in the sibling JSON. Logs: root503-f3-finite-baseline-red.log, root503-f3-finite-after.log, scoped-eslint/types logs. Independent review is pending from sc051_sc068_final_review; root must require current-head CI and qualify any remaining real NULL row before claiming the mandatory gate green.
