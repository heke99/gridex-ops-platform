// UNAPPLIED proposal only. Replace only the obsolete page /Fakturering/ assert;
// preserve its label and all other26 actual assertions. No product/UI change.
// Added declaration/read/helpers below use the already declared TypeScript parser.
const ts = require('typescript')
const detailPage = read('app/admin/customers/[id]/page.part-4.tsx')
const parsePage = (name, text) => ts.createSourceFile(name, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)
const facadeTree = parsePage('page.tsx', page)
const detailTree = parsePage('page.part-4.tsx', detailPage)
const facadeDelegates = facadeTree.statements.some(node =>
  ts.isExportDeclaration(node) && node.moduleSpecifier?.text === './page.part-4'
  && node.exportClause && ts.isNamedExports(node.exportClause)
  && node.exportClause.elements.some(item => item.name.text === 'default' && item.propertyName?.text === 'CustomerAdminDetailPage'))
const billingImport = detailTree.statements.some(node =>
  ts.isImportDeclaration(node) && node.moduleSpecifier.text === '@/components/admin/customers/CustomerBillingMeteringCard'
  && node.importClause?.name?.text === 'CustomerBillingMeteringCard')
const namedPages = detailTree.statements.filter(node => ts.isFunctionDeclaration(node) && node.name?.text === 'CustomerAdminDetailPage')
const actualReturn = namedPages.length === 1 ? namedPages[0].body?.statements.filter(ts.isReturnStatement).at(-1) : null
const guardedSections = []
function findBillingSection(node) {
  if (!node) return
  if (ts.isConditionalExpression(node) && ts.isBinaryExpression(node.condition)
    && ts.isIdentifier(node.condition.left) && node.condition.left.text === 'activeTab'
    && node.condition.operatorToken.kind === ts.SyntaxKind.EqualsEqualsEqualsToken
    && ts.isStringLiteral(node.condition.right) && node.condition.right.text === 'billing-metering'
    && node.whenFalse.kind === ts.SyntaxKind.NullKeyword) {
    let section = node.whenTrue
    while (ts.isParenthesizedExpression(section)) section = section.expression
    if (ts.isJsxElement(section) && section.openingElement.tagName.getText(detailTree) === 'SectionAnchor') guardedSections.push(section)
  }
  ts.forEachChild(node, findBillingSection)
}
findBillingSection(actualReturn?.expression)
function attr(element, name) { return element?.attributes.properties.find(node => ts.isJsxAttribute(node) && node.name.text === name)?.initializer }
const billingSection = guardedSections.length === 1 ? guardedSections[0] : null
const cards = billingSection?.children.filter(node => ts.isJsxSelfClosingElement(node) && node.tagName.getText(detailTree) === 'CustomerBillingMeteringCard') ?? []
const expectedProps = {customerId:'id',sites:'sites',meteringPoints:'meteringPoints',gridOwners:'gridOwners',dataRequests:'dataRequests',meteringValues:'meteringValues',billingUnderlays:'billingUnderlays',partnerExports:'partnerExports',outboundRequests:'outboundRequests',isPlatformAdmin:'isPlatformAdmin'}
assert(
  facadeDelegates && billingImport && guardedSections.length === 1
    && attr(billingSection?.openingElement, 'id')?.text === 'billing-metering'
    && attr(billingSection?.openingElement, 'title')?.text === 'Fakturering'
    && cards.length === 1
    && Object.entries(expectedProps).every(([name, expected]) => {
      const value = attr(cards[0], name)
      return value && ts.isJsxExpression(value) && value.expression && ts.isIdentifier(value.expression) && value.expression.text === expected
    }),
  'customer page exposes the billing business surface',
)
// Bounded static surface characterization only. The separately source-qualified
// real loaders/status/link/permissions/approval effects are not executed here.
